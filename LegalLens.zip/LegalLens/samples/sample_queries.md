# Sample queries for `sample_contract.pdf`

Contract: Freelance Services and Confidentiality Agreement (Northwind Studio, Aarav Mehta). 11 clauses, 2 pages.

## 1. Questions the contract can answer

| Query | Expected answer | Risk |
|---|---|---|
| What are the penalties if I miss a deadline? | INR 5,000 deducted for each day of delay (Clause 2) | HIGH |
| What happens if I breach confidentiality? | Immediate termination and a $10,000 fine (Clause 5) | HIGH |
| How can this contract be terminated, and by whom? | Company: any time, no notice, sole discretion. Contractor: 60 days written notice and must repay fees for undelivered work (Clause 4) | HIGH |
| Does the contract renew automatically? | Yes, for 12-month periods unless notice is given 90 days before the term ends (Clause 3) | HIGH |
| What are the payment terms? | INR 50,000 per month, invoices payable within 45 days of receipt (Clause 2) | MEDIUM |
| Can I work for competitors after the contract ends? | No, for 24 months after the term, anywhere in India (Clause 7) | HIGH |
| Who owns the work I create? | The Company. The Contractor assigns all rights and cannot show the work in a portfolio (Clause 6) | HIGH |
| Who is liable if something goes wrong? | Contractor must indemnify the Company. Company liability is capped at one month of fees (Clause 8) | HIGH |
| Can the Company change my fees? | Yes, at any time by notice, without consent, effective after 7 days (Clause 9) | HIGH |
| Which law applies and where are disputes settled? | Laws of India, arbitration in Bengaluru (Clause 10) | MEDIUM |
| Explain the termination clause like I am 5 | Simple wording of Clause 4 (tests that style requests stay in scope) | HIGH |
| *(leave blank)* | Full triage of obligations, deadlines, penalties and risks | - |

## 2. Question the contract cannot answer

Expected result: "This document does not seem to answer that."

- What is the warranty period for the delivered designs?
- Is there a health insurance benefit?

## 3. Out-of-scope questions

Expected result: "That question is not about this document."

- What is the capital of France?
- Write me a joke about cats.
- Write a Python function to sort a list.

## 4. Quick scan checks (no AI)

The Quick scan tab should show these:

- **Flags:** Automatic renewal, Liability and indemnity, Penalties and fines, Non-compete and exclusivity, One-sided changes, Termination, Payment terms, Intellectual property, Disputes and governing law, Confidentiality
- **Money:** INR 50,000, INR 5,000, $10,000
- **Time periods:** 45 days, 12 months, 90 days, 60 days, 24 months, 7 days
- **Dates:** 1 January 2026

## 5. Law library questions (after running `fetch_open_india_law.py`)

Fetch the Indian Contract Act first:

```
python fetch_open_india_law.py --kind legislation --title-contains "Contract" --limit 3
```

Then pick it under **Law library** in the sidebar. The expected points below are from my knowledge of the Act, so check them against the PDF you fetched, because the snapshot may differ.

| Query | What to look for |
|---|---|
| What does section 73 say about compensation for breach of contract? | Compensation for loss or damage caused by breach |
| What does section 74 say when a penalty is written into a contract? | Compensation for breach where a sum or penalty is stipulated |
| Are agreements in restraint of trade valid? (section 27) | Generally void, with a narrow exception. Compare with the non-compete in the sample contract |
| Who is covered by this Act, and are there exceptions? | Tests the "Who is covered?" quick question |

For judgments, use `--kind judgments --file in_kerala_judgments.parquet` and ask "What did the court decide, and why?"
These are archives, not current law. Check the official source before relying on anything.
